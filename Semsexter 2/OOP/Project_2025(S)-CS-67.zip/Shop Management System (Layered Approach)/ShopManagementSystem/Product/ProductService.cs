using ShopManagementSystem.Common;

namespace ShopManagementSystem.Product
{
    internal class ProductService
    {
        private List<ProductModel> allProducts;
        private ProductRepository repo;

        public ProductService()
        {
            repo = new ProductRepository();
            allProducts = repo.GetAll();
        }

        public void Add(ProductModel product)
        {
            allProducts.Add(product);
            repo.Add(product);
        }

        public void Update(ProductModel updated)
        {
            for (int i = 0; i < allProducts.Count; i++)
            {
                if (allProducts[i].GetName() == updated.GetName())
                {
                    allProducts[i] = new ProductModel(updated);
                    break;
                }
            }
            repo.SaveAll(allProducts);
        }

        public void Delete(string name)
        {
            foreach (ProductModel product in allProducts)
            {
                if (product.GetName() == name)
                {
                    allProducts.Remove(product);
                    repo.SaveAll(allProducts);
                    break;
                }
            }
        }

        public List<ProductModel> GetAll()
        {
            return allProducts;
        }

        public ProductModel GetProductByName(string name)
        {
            foreach (ProductModel product in allProducts)
            {
                if (product.GetName() == name) return product;
            }
            return null;
        }
        
        public bool Exists(string name)
        {
            foreach (ProductModel product in allProducts)
            {
                if (product.GetName() == name) return true;
            }
            return false;
        }
    }
} 