using System;
using ShopManagementSystem.Common;

namespace ShopManagementSystem.Product
{
    internal class ProductUI
    {
        private ProductService service;

        public ProductUI()
        {
            service = new ProductService();
        }

        public void StartLoop()
        {
            while (true)
            {
                string option = ProductMenu();
                if (option == "0") break;
                else if (option == "1") AddProductUI();
                else if (option == "2") UpdateProductUI();
                else if (option == "3") DeleteProductUI();
                else if (option == "4") ViewAllProducts();
                else ConsoleUtiles.PauseForKeyPress("Invalid Input!");
            }
        }
        public string ProductMenu()
        {
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.Black;
            Console.WriteLine("---------------------------------------------------");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("\n                PRODUCT MANGEMENT                \n\n" +

                              "---------------------------------------------------\n"
            );
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.Write("1. "); Console.ForegroundColor = ConsoleColor.Black; Console.WriteLine("Add New Product\n");
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.Write("2. "); Console.ForegroundColor = ConsoleColor.Black; Console.WriteLine("Update Product\n");
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.Write("3. "); Console.ForegroundColor = ConsoleColor.Black; Console.WriteLine("Delete Product\n");
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.Write("4. "); Console.ForegroundColor = ConsoleColor.Black; Console.WriteLine("View All Products\n");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("0. Go Back to Main Menu\n\n" +
                              "---------------------------------------------------\n"
            );
            Console.ForegroundColor = ConsoleColor.Black;
            Console.Write("Enter your choice: ");

            return Console.ReadLine();
        }

        private void AddProductUI()
        {
            while (true)
            {
                Console.Clear();
                AddProductHeader();

                // Name
                Console.Write("Enter Product's Name: ");
                string name = Console.ReadLine();
                if (name.ToLower() == "exit") break;
                if (name == "") continue;
                if (service.Exists(name))
                {
                    ConsoleUtiles.PauseForKeyPress("Product Already Exists.");
                    continue;
                }

                // Purchase Price
                double purchasePrice;
                while (true)
                {
                    Console.Write("\nEnter Product's purchase price: ");
                    string purchasePriceStr = Console.ReadLine();
                    if (purchasePriceStr.ToLower() == "exit") return;
                    if (purchasePriceStr == "") continue;
                    if (!double.TryParse(purchasePriceStr, out purchasePrice))
                    {
                        Console.WriteLine("\nInvalid Input!");
                        continue;
                    }
                    break;
                }

                // Discount
                double discountPercentage = 0;
                while (true)
                {
                    Console.Write("Do you want to add a discount for this product? (Yes/No): ");
                    string choice = Console.ReadLine();
                    if (choice.ToLower() == "exit") break;
                    if (choice == "") continue;
                    if (choice.ToLower() == "no") break;
                    else if (choice.ToLower() == "yes")
                    {
                        while (true)
                        {
                            Console.Write("\nEnter discount percentage: ");
                            string discountPercentageStr = Console.ReadLine();
                            if (discountPercentageStr.ToLower() == "exit") return;
                            if (discountPercentageStr == "") continue;
                            if (!double.TryParse(discountPercentageStr, out discountPercentage))
                            {
                                Console.WriteLine("\nInvalid Input!");
                                continue;
                            }
                            break;
                        }
                    }
                    break;
                }
                service.Add(new ProductModel(name, purchasePrice, discountPercentage));
                break;
            }
        }
        private void AddProductHeader()
        {
            Console.ForegroundColor = ConsoleColor.Black;
            Console.WriteLine("----------------------------------------------------");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("\n                 ADD NEW PRODUCT                  \n\n" +

                              "----------------------------------------------------\n\n" +

                              "You can type \"exit\" to go back anytime.\n"
            );
            Console.ForegroundColor = ConsoleColor.Black;
        }

        private void UpdateProductUI()
        {
            Console.Clear();
            UpdateProductHeader();

            while (true)
            {
                Console.Write("Enter Product's Name: ");
                string name = Console.ReadLine();
                if (name.ToLower() == "exit") break;
                if (name == "") continue;
                if (!service.Exists(name))
                {
                    ConsoleUtiles.PauseForKeyPress("Product Not Found.");
                    continue;
                }
                else
                {
                    StartUpdateLoop(service.GetProductByName(name));
                    break;
                }
            }
        }
        private void StartUpdateLoop(ProductModel product)
        {
            ProductModel updated = new ProductModel(product);
            string lastOption = "Cancel";
            while (true)
            {
                Console.Clear();
                string option = UpdateMenu(updated, lastOption);

                if (option.ToLower() == "exit" || option == "0") break;
                else if (option == "1")
                {
                    double purchasePrice;
                    while (true)
                    {
                        Console.Write("\nEnter new purchase price: ");
                        string purchasePriceStr = Console.ReadLine();
                        if (purchasePriceStr.ToLower() == "exit") return;
                        if (purchasePriceStr == "") continue;
                        if (!double.TryParse(purchasePriceStr, out purchasePrice))
                        {
                            Console.WriteLine("\nInvalid Input!");
                            continue;
                        }
                        break;
                    }
                    updated.SetPurchasePrice(purchasePrice);
                    service.Update(updated);
                    lastOption = "Done? Go Back";
                }
                else if (option == "2")
                {
                    double discountPercentage;
                    while (true)
                    {
                        Console.Write("\nEnter new discount percentage: ");
                        string discountPercentageStr = Console.ReadLine();
                        if (discountPercentageStr.ToLower() == "exit") return;
                        if (discountPercentageStr == "") continue;
                        if (!double.TryParse(discountPercentageStr, out discountPercentage))
                        {
                            Console.WriteLine("\nInvalid Input");
                            continue;
                        }
                        break;
                    }
                    updated.SetDiscount(discountPercentage);
                    service.Update(updated);
                    lastOption = "Done? Go Back";
                }
                else
                {
                    ConsoleUtiles.PauseForKeyPress("Invalid Choice!");
                }
            }
            service.Update(updated);
        }
        private string UpdateMenu(ProductModel product, string lastOption)
        {
            UpdateProductHeader();
            Console.WriteLine("What do you want to update?\n");
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.Write("1. "); Console.ForegroundColor = ConsoleColor.Black; Console.WriteLine("Product Price (Current: $" + product.GetPurchasePrice() + ")\n");
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.Write("2. "); Console.ForegroundColor = ConsoleColor.Black; Console.WriteLine("Product Discount (Current: " + product.GetDiscount() + ")\n");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("0. " + lastOption + "\n\n" +
                              "----------------------------------------------------\n"
            );
            Console.ForegroundColor = ConsoleColor.Black;
            Console.Write("Enter your choice: ");
            return Console.ReadLine();
        }
        private void UpdateProductHeader()
        {
            Console.ForegroundColor = ConsoleColor.Black;
            Console.WriteLine("---------------------------------------------------");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("\n                 UPDATE PRODUCT                  \n\n" +

                              "---------------------------------------------------\n\n" +

                                "You can type \"exit\" to go back anytime.\n"
            );
            Console.ForegroundColor = ConsoleColor.Black;
        }

        private void DeleteProductUI()
        {
            string name;
            while (true)
            {
                Console.Clear();
                DeleteProductHeader();
                Console.Write("\nEnter Product Name: ");
                name = Console.ReadLine();
                if (name.ToLower() == "exit") break;
                if (name == "") continue;
                if (!service.Exists(name))
                {
                    ConsoleUtiles.PauseForKeyPress("Product Not Found.");
                    continue;
                }
                break;
            }
            service.Delete(name);
            ConsoleUtiles.PauseForKeyPress("Product Deleted.");
        }
        private void DeleteProductHeader()
        {
            Console.ForegroundColor = ConsoleColor.Black;
            Console.WriteLine("---------------------------------------------------");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("\n                 DELETE PRODUCT                  \n\n" +

                              "---------------------------------------------------\n\n" +

                              "You can type \"exit\" to go back anytime.\n"
            );
            Console.ForegroundColor = ConsoleColor.Black;
        }

        private void ViewAllProducts()
        {
            Console.Clear();
            ViewAllProductsHeader();
            List<ProductModel> products = service.GetAll();
            for (int i = 0; i < products.Count; i++)
            {
                Console.ForegroundColor = ConsoleColor.Blue;
                Console.WriteLine(i + 1 + ". Name: " + products[i].GetName());
                Console.ForegroundColor = ConsoleColor.Black;
                Console.WriteLine("\t" + products[i].GetInfo() + "\n");
            }
            ConsoleUtiles.PauseForKeyPress("");
        }
        private void ViewAllProductsHeader()
        {
            Console.ForegroundColor = ConsoleColor.Black;
            Console.WriteLine("----------------------------------------------------");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("\n                VIEW ALL PRODUCTS                 \n\n" +

                              "----------------------------------------------------\n"
            );
            Console.ForegroundColor = ConsoleColor.Black;
        }
    } 
}