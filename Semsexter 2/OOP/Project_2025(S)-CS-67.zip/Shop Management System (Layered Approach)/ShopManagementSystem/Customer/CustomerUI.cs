using System;
using ShopManagementSystem.Common;

namespace ShopManagementSystem.Customer
{
    internal class CustomerUI
    {
        private CustomerService service;

        public CustomerUI()
        {
            service = new CustomerService(); 
        }
        public void StartLoop()
        {
            while (true)
            {
                string option = CustomerMenu();
                if (option == "0") break;
                else if (option == "1") AddCustomerUI();
                else if (option == "2") UpdateCustomerUI();
                else if (option == "3") DeleteCustomerUI();
                else if (option == "4") ViewAllCustomers();
                else ConsoleUtiles.PauseForKeyPress("Invalid Input!");
            }
        }
        private string CustomerMenu()
        {
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.Black;
            Console.WriteLine("----------------------------------------------------");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("\n                CUSTOMER MANGEMENT                \n\n" +

                              "----------------------------------------------------\n"
            );
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.Write("1. "); Console.ForegroundColor = ConsoleColor.Black; Console.WriteLine("Add New Customer\n");
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.Write("2. "); Console.ForegroundColor = ConsoleColor.Black; Console.WriteLine("Update Customer\n");
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.Write("3. "); Console.ForegroundColor = ConsoleColor.Black; Console.WriteLine("Delete Customer\n");
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.Write("4. "); Console.ForegroundColor = ConsoleColor.Black; Console.WriteLine("View All Customers\n");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("0. Go Back to Main Menu\n\n" +
                              "----------------------------------------------------\n"
            );
            Console.ForegroundColor = ConsoleColor.Black;
            Console.Write("Enter your choice: ");

            return Console.ReadLine();
        }
        
        public void AddCustomerUI()
        {
            while (true)
            {
                Console.Clear();
                AddCustomerHeader();

                // Name
                Console.Write("Enter Customer's Name: ");
                string name = Console.ReadLine();
                if (name.ToLower() == "exit") break;
                if (name == "") continue;
                if (service.Exists(name))
                {
                    ConsoleUtiles.PauseForKeyPress("Customer Already Exists.");
                    continue;
                }

                // Phone Number
                string phoneNumber;
                while (true)
                {
                    Console.Write("\nEnter Customer's Phone Number: ");
                    phoneNumber = Console.ReadLine();
                    if (phoneNumber.ToLower() == "exit") return;
                    if (phoneNumber == "") continue;
                    if (!OtherUtils.IsAllDigits(phoneNumber))
                    {
                        Console.WriteLine("\nInvalid Input!");
                        continue;
                    }
                    break;
                }

                // Age
                int age;
                while (true)
                {
                    Console.Write("\nEnter Customer's age: ");
                    string ageStr = Console.ReadLine();
                    if (ageStr.ToLower() == "exit") return;
                    if (ageStr == "") continue;
                    if (!int.TryParse(ageStr, out age))
                    {
                        Console.WriteLine("\nInvalid Input!");
                        continue;
                    }
                    break;
                }

                // Address
                string address;
                while (true)
                {
                    Console.Write("\nEnter Customer's Address: ");
                    address = Console.ReadLine();
                    if (address.ToLower() == "exit") return;
                    if (address == "") continue;
                    break;
                }

                service.Add(new CustomerModel(name, phoneNumber, age, address));
                break;
            }
        }
        private void AddCustomerHeader()
        {
            Console.ForegroundColor = ConsoleColor.Black;
            Console.WriteLine("----------------------------------------------------");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("\n                 ADD NEW CUSTOMER                 \n\n" +

                              "----------------------------------------------------\n\n" +

                              "You can type \"exit\" to go back anytime.\n"
            );
            Console.ForegroundColor = ConsoleColor.Black;
        }

        private void UpdateCustomerUI()
        {
            Console.Clear();
            UpdateCustomerHeader();

            while (true)
            {
                Console.Write("Enter Customer's Name: ");
                string name = Console.ReadLine();
                if (name.ToLower() == "exit") break;
                if (name == "") continue;
                if (!service.Exists(name))
                {
                    ConsoleUtiles.PauseForKeyPress("Customer Not Found.");
                    continue;
                }
                else
                {
                    StartUpdateLoop(service.GetCustomerByName(name));
                    break;
                }
            }
        }
        private void StartUpdateLoop(CustomerModel customer)
        {
            CustomerModel updated = new CustomerModel(customer);
            string lastOption = "Cancel";
            while (true)
            {
                Console.Clear();
                string option = UpdateMenu(updated, lastOption);

                if (option.ToLower() == "exit" || option == "0") break;
                else if (option == "1")
                {
                    string phoneNumber;
                    while (true)
                    {
                        Console.Write("\nEnter new phone number: ");
                        phoneNumber = Console.ReadLine();
                        if (phoneNumber.ToLower() == "exit") return;
                        if (phoneNumber == "") continue;
                        if (!OtherUtils.IsAllDigits(phoneNumber))
                        {
                            Console.WriteLine("\nInvalid Input!");
                            continue;
                        }
                        break;
                    }
                    updated.SetPhoneNumber(phoneNumber);
                    service.Update(updated);
                    lastOption = "Done? Go Back";
                }
                else if (option == "2")
                {
                    int age;
                    while (true)
                    {
                        Console.Write("\nEnter new age: ");
                        string ageStr = Console.ReadLine();
                        if (ageStr.ToLower() == "exit") return;
                        if (ageStr == "") continue;
                        if (!int.TryParse(ageStr, out age))
                        {
                            Console.WriteLine("\nInvalid Input");
                            continue;
                        }
                        break;
                    }
                    updated.SetAge(age);
                    service.Update(updated);
                    lastOption = "Done? Go Back";
                }
                else if (option == "3")
                {
                    string address;
                    while (true)
                    {
                        Console.Write("\nEnter new address: ");
                        address = Console.ReadLine();
                        if (address.ToLower() == "exit") return;
                        if (address == "") continue;
                        break;
                    }
                    updated.SetAddress(address);
                    service.Update(updated);
                    lastOption = "Done? Go Back";
                }
                else
                {
                    ConsoleUtiles.PauseForKeyPress("Invalid Choice!");
                }
            }
        }
        private string UpdateMenu(CustomerModel customer, string lastOption)
        {
            UpdateCustomerHeader();
            Console.WriteLine("What do you want to update?\n");
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.Write("1. "); Console.ForegroundColor = ConsoleColor.Black; Console.WriteLine("Customer's Phone Number (Current: " + customer.GetPhoneNumber() + ")\n");
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.Write("2. "); Console.ForegroundColor = ConsoleColor.Black; Console.WriteLine("Customer's Age (Current: " + customer.GetAge() + ")\n");
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.Write("3. "); Console.ForegroundColor = ConsoleColor.Black; Console.WriteLine("Customer's Address (Current: " + customer.GetAddress() + ")\n");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("0. " + lastOption + "\n\n" +
                              "----------------------------------------------------\n"
            );
            Console.ForegroundColor = ConsoleColor.Black;
            Console.Write("Enter your choice: ");
            return Console.ReadLine();
        }
        private void UpdateCustomerHeader()
        {
            Console.ForegroundColor = ConsoleColor.Black;
            Console.WriteLine("---------------------------------------------------");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("\n                 UPDATE CUSTOMER                 \n\n" +

                              "---------------------------------------------------\n\n" +

                                "You can type \"exit\" to go back anytime.\n"
            );
            Console.ForegroundColor = ConsoleColor.Black;
        }

        private void DeleteCustomerUI()
        {
            string name;
            while (true)
            {
                Console.Clear();
                DeleteCustomerHeader();
                Console.Write("\nEnter Customer Name: ");
                name = Console.ReadLine();
                if (name.ToLower() == "exit") break;
                if (name == "") continue;
                if (!service.Exists(name))
                {
                    ConsoleUtiles.PauseForKeyPress("Customer Not Found.");
                    continue;
                }
                break;
            }
            service.Delete(name);
            ConsoleUtiles.PauseForKeyPress("Customer Deleted.");
        }
        private void DeleteCustomerHeader()
        {
            Console.ForegroundColor = ConsoleColor.Black;
            Console.WriteLine("---------------------------------------------------");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("\n                 DELETE CUSTOMER                 \n\n" +

                              "---------------------------------------------------\n\n" +

                              "You can type \"exit\" to go back anytime.\n"
            );
            Console.ForegroundColor = ConsoleColor.Black;
        }

        private void ViewAllCustomers()
        {
            Console.Clear();
            ViewAllCustomersHeader();
            List<CustomerModel> customers = service.GetAll();
            for (int i = 0; i < customers.Count(); i++)
            {
                Console.ForegroundColor = ConsoleColor.Blue;
                Console.WriteLine(i + 1 + ". Name: " + customers[i].GetName());
                Console.ForegroundColor = ConsoleColor.Black;
                Console.WriteLine("\t" + customers[i].GetInfo() + "\n");
            }
            ConsoleUtiles.PauseForKeyPress("");
        }
        private void ViewAllCustomersHeader()
        {
            Console.ForegroundColor = ConsoleColor.Black;
            Console.WriteLine("----------------------------------------------------");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("\n                VIEW ALL CUSTOMERS                \n\n" +

                              "----------------------------------------------------\n"
            );
            Console.ForegroundColor = ConsoleColor.Black;
        }
    }
}