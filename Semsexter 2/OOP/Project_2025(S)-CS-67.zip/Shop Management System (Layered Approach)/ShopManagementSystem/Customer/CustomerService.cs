using ShopManagementSystem.Common;

namespace ShopManagementSystem.Customer
{
    internal class CustomerService
    {
        private List<CustomerModel> allCustomers;

        private CustomerRepository repo;
 
        public CustomerService()
        {
            repo = new CustomerRepository();
            allCustomers = repo.GetAll();
        }

        public void Add(CustomerModel customer)
        {
            allCustomers.Add(customer);
            repo.Add(customer);
        }

        public void Update(CustomerModel updated)
        {
            for (int i = 0; i < allCustomers.Count; i++)
            {
                if (allCustomers[i].GetName() == updated.GetName())
                {
                    allCustomers[i] = new CustomerModel(updated);
                    break;
                }
            }
            repo.SaveAll(allCustomers);
        }

        public void Delete(string name)
        {
            foreach (CustomerModel customer in allCustomers)
            {
                if (customer.GetName() == name)
                {
                    allCustomers.Remove(customer);
                    repo.SaveAll(allCustomers);
                    break;
                }
            }
        }

        public List<CustomerModel> GetAll()
        {
            return allCustomers;
        }
        
        public CustomerModel GetCustomerByName(string name)
        {
            foreach (CustomerModel customer in allCustomers)
            {
                if (customer.GetName() == name) return customer;
            }
            return null;
        }

        public bool Exists(string name)
        {
            foreach (CustomerModel customer in allCustomers)
            {
                if (customer.GetName() == name) return true;
            }
            return false;
        }
    }
}