namespace ShopManagementSystem.Common
{
    internal static class ConsoleUtiles
    {
        public static void PauseForKeyPress(string message)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.Write("\n" + message + " Press any key to continue...");
            Console.ForegroundColor = ConsoleColor.Black;
            Console.ReadKey();
        }
    }
}