using ShopManagementSystem.Common;

namespace ShopManagementSystem.Customer
{
    internal class CustomerService
    {
        private CustomerRepositoryDB repoDB;
 
        public CustomerService()
        {
            repoDB = new CustomerRepositoryDB();
        }

        public bool Create(CustomerModel customer)
        {
            if (repoDB.GetByPhoneNumber(customer.phoneNumber) != null)
            {
                return false;
            }
            return repoDB.Create(customer);
        }

        public bool Update(CustomerModel updated)
        {
            return repoDB.Update(new CustomerModel(updated));
        }

        public bool Delete(int id)
        {
            return repoDB.Delete(id);
        }

        public List<CustomerModel> GetAll()
        {
            return repoDB.GetAll();
        }

        public CustomerModel GetCustomerById(int id)
        {
            return repoDB.GetCustomerById(id);
        }

        public List<CustomerModel> GetCustomerByName(string name)
        {
            return repoDB.GetByName(name);
        }
        public List<CustomerModel> GetCustomerByFirstChar(string ch)
        {
            return repoDB.GetByFirstChar(ch);
        }
        public CustomerModel GetCustomerByPhoneNumber(string phoneNumber)
        {
            return repoDB.GetByPhoneNumber(phoneNumber);
        }

        public List<CustomerModel> GetCustomerByAddress(string address)
        {
            return repoDB.GetByAddress(address);
        }

        public List<CustomerModel> GetCustomerByAge(int age)
        {
            return repoDB.GetByAge(age);
        }

        public bool Exists(int id)
        {
            /*foreach (CustomerModel customer in allCustomers)
            {
                if (customer.GetName() == name) return true;
            }
            return false;*/
            return repoDB.Exists(id);
        }
    }
}